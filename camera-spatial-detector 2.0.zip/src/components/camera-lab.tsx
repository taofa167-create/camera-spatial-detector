import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as cocoSsd from "@tensorflow-models/coco-ssd";
import * as tf from "@tensorflow/tfjs";
import {
  Camera,
  Check,
  CircleAlert,
  Cpu,
  Gauge,
  LockKeyhole,
  Play,
  RotateCcw,
  Square,
} from "lucide-react";

import { describeRelation, type BBox } from "@/lib/spatial";

type AppState =
  | "idle"
  | "model-loading"
  | "camera-starting"
  | "camera-live"
  | "running"
  | "error";
type CameraError = { title: string; detail: string; action: string };
type Detection = cocoSsd.DetectedObject;
type PositionedDetection = Detection & {
  display: { left: number; top: number; width: number; height: number };
};

/** Strict 2.0-second throttled scan cadence. */
const SCAN_INTERVAL = 2000;
/** Strict 2-object limit passed to model.detect(video, maxNumBoxes). */
const MAX_NUM_BOXES = 2;
/** Minimum on-screen hold for a spatial HUD reading before it may clear. */
const HUD_HOLD_MS = 4500;

function formatTime(value: number | null) {
  if (!value) return "—";
  return new Intl.DateTimeFormat(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(value);
}

function readableCameraError(error: unknown): CameraError {
  const name = error instanceof DOMException ? error.name : "";
  if (name === "NotAllowedError" || name === "SecurityError") {
    return {
      title: "Camera permission was not granted",
      detail:
        "Allow camera access in your browser settings, then try again. Access is only requested when you press the control below.",
      action: "Check browser permissions",
    };
  }
  if (name === "NotFoundError" || name === "OverconstrainedError") {
    return {
      title: "No rear camera was found",
      detail:
        "Connect a camera or switch to a device with a rear-facing camera. The detector prefers the environment-facing lens.",
      action: "Check camera hardware",
    };
  }
  if (name === "NotReadableError" || name === "AbortError") {
    return {
      title: "Camera is busy",
      detail: "Another app or browser tab may be using the camera. Close it and try again.",
      action: "Release camera and retry",
    };
  }
  if (!window.isSecureContext) {
    return {
      title: "Secure context required",
      detail:
        "Camera access needs HTTPS or localhost. Open this test from a secure origin, then try again.",
      action: "Open a secure URL",
    };
  }
  return {
    title: "Camera could not start",
    detail:
      "The browser did not provide a usable camera stream. Check the device and browser permissions, then try again.",
    action: "Check device and retry",
  };
}

function StatusDot({ state }: { state: AppState }) {
  const active = state === "running";
  const loading = state === "model-loading" || state === "camera-starting";
  return (
    <span
      aria-hidden="true"
      className={`inline-block h-2 w-2 rounded-full ${
        active
          ? "bg-accent"
          : loading
            ? "status-pulse bg-primary"
            : state === "error"
              ? "bg-destructive"
              : "bg-muted-foreground"
      }`}
    />
  );
}

export default function CameraLab() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const modelRef = useRef<cocoSsd.ObjectDetection | null>(null);
  const timerRef = useRef<number | null>(null);
  const detectingRef = useRef(false);
  /** Timestamp of the last successful 2-object HUD write (persistence memory). */
  const hudLockedAtRef = useRef<number | null>(null);

  const [state, setState] = useState<AppState>("idle");
  const [error, setError] = useState<CameraError | null>(null);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [relationshipText, setRelationshipText] = useState("");
  const [lastScan, setLastScan] = useState<number | null>(null);
  const [videoDimensions, setVideoDimensions] = useState("—");
  const [stageSize, setStageSize] = useState({ width: 1, height: 1 });
  const [secureContext, setSecureContext] = useState(false);
  const [hasStream, setHasStream] = useState(false);
  const [modelStatus, setModelStatus] = useState<"NOT LOADED" | "LOADING" | "READY">(
    "NOT LOADED",
  );

  useEffect(() => setSecureContext(window.isSecureContext), []);

  const stopCamera = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    detectingRef.current = false;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setHasStream(false);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.srcObject = null;
    }
  }, []);

  /** One frame grab per interval tick; idle in between. */
  const runDetection = useCallback(async () => {
    const video = videoRef.current;
    const detector = modelRef.current;
    if (
      !video ||
      !detector ||
      video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA ||
      detectingRef.current
    ) {
      return;
    }
    detectingRef.current = true;
    try {
      const predictions = await detector.detect(video, MAX_NUM_BOXES);
      setDetections(predictions);
      setLastScan(Date.now());

      const first = predictions[0];
      const second = predictions[1];
      if (first && second) {
        // Fresh 2-object match: overwrite the buffer and restart the hold clock.
        setRelationshipText(
          describeRelation(
            first.class,
            first.bbox as BBox,
            second.class,
            second.bbox as BBox,
          ),
        );
        hudLockedAtRef.current = Date.now();
      } else {
        // Dropout/flicker: hold the last reading until its 4.5s clock expires.
        const lockedAt = hudLockedAtRef.current;
        if (lockedAt !== null && Date.now() - lockedAt < HUD_HOLD_MS) {
          // Keep the existing HUD text visible.
        } else {
          setRelationshipText("");
          hudLockedAtRef.current = null;
        }
      }
    } catch (detectionError) {
      console.warn("COCO-SSD scan failed", detectionError);
    } finally {
      detectingRef.current = false;
    }
  }, []);

  const startCamera = useCallback(async () => {
    if (state === "model-loading" || state === "camera-starting") return;
    stopCamera();
    setError(null);
    setDetections([]);
    setRelationshipText("");
    hudLockedAtRef.current = null;
    setLastScan(null);
    setState("camera-starting");

    let video: HTMLVideoElement;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
      });
      streamRef.current = stream;
      setHasStream(true);
      const element = videoRef.current;
      if (!element) throw new Error("Video element is unavailable");
      video = element;
      video.srcObject = stream;

      // Stream validation: hold inference until metadata reports live dimensions.
      if (!video.videoWidth) {
        await new Promise<void>((resolve) => {
          video.addEventListener("loadedmetadata", () => resolve(), { once: true });
        });
      }
      await video.play();
      setVideoDimensions(`${video.videoWidth} × ${video.videoHeight}`);
      setState("camera-live");
    } catch (cameraError) {
      stopCamera();
      setError(readableCameraError(cameraError));
      setState("error");
      return;
    }

    try {
      setState("model-loading");
      setModelStatus("LOADING");
      try {
        await tf.setBackend("webgl");
      } catch {
        // TensorFlow.js falls back to its available backend.
      }
      await tf.ready();
      const loadedModel = modelRef.current ?? (await cocoSsd.load());
      modelRef.current = loadedModel;
      setModelStatus("READY");
      setState("running");
      timerRef.current = window.setInterval(() => void runDetection(), SCAN_INTERVAL);
      void runDetection();
    } catch {
      setModelStatus("NOT LOADED");
      setError({
        title: "COCO-SSD model could not load",
        detail:
          "The camera is live, but the detector model did not finish loading. Check the connection, then retry the test.",
        action: "Retry model load",
      });
      setState("error");
    }
  }, [runDetection, state, stopCamera]);

  const stop = useCallback(() => {
    stopCamera();
    setDetections([]);
    setRelationshipText("");
    hudLockedAtRef.current = null;
    setLastScan(null);
    setVideoDimensions("—");
    setState("idle");
  }, [stopCamera]);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const observer = new ResizeObserver(([entry]) => {
      if (!entry) return;
      setStageSize({
        width: entry.contentRect.width || 1,
        height: entry.contentRect.height || 1,
      });
    });
    observer.observe(stage);
    return () => observer.disconnect();
  }, []);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const statusText =
    state === "running"
      ? "Detection active"
      : state === "model-loading"
        ? "Loading COCO-SSD model"
        : state === "camera-starting"
          ? "Starting rear camera"
          : state === "camera-live"
            ? "Camera live"
            : state === "error"
              ? "Needs attention"
              : "Ready to test";

  const statusDescription =
    state === "running"
      ? "Camera feed is live and scanning every 2 seconds"
      : state === "model-loading"
        ? "Preparing the local object detector"
        : state === "camera-starting"
          ? "Waiting for a camera frame"
          : state === "camera-live"
            ? "Camera is live; preparing the detector"
            : state === "error"
              ? "The test could not start"
              : "Start a local camera and model check";

  const positionedDetections = useMemo<PositionedDetection[]>(() => {
    const video = videoRef.current;
    if (!video || !video.videoWidth || !video.videoHeight) return [];
    const sourceRatio = video.videoWidth / video.videoHeight;
    const stageRatio = stageSize.width / stageSize.height;
    const scale =
      stageRatio > sourceRatio
        ? stageSize.width / video.videoWidth
        : stageSize.height / video.videoHeight;
    const renderedWidth = video.videoWidth * scale;
    const renderedHeight = video.videoHeight * scale;
    const offsetX = (stageSize.width - renderedWidth) / 2;
    const offsetY = (stageSize.height - renderedHeight) / 2;
    return detections.map((detection) => ({
      ...detection,
      display: {
        left: offsetX + detection.bbox[0] * scale,
        top: offsetY + detection.bbox[1] * scale,
        width: detection.bbox[2] * scale,
        height: detection.bbox[3] * scale,
      },
    }));
  }, [detections, stageSize]);

  const running = state === "running" || state === "camera-live";

  return (
    <main className="lab-app flex h-full min-h-[100dvh] flex-col">
      <header className="relative z-10 flex shrink-0 items-center justify-between border-b border-border bg-panel/90 px-4 py-3 backdrop-blur-md sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center border border-primary/55 bg-primary/10 text-primary">
            <Camera size={17} strokeWidth={1.7} />
          </div>
          <div>
            <div className="instrument-mono uppercase text-muted-foreground">
              FIELD TEST / 01
            </div>
            <h1 className="text-sm font-semibold tracking-[0.13em] text-foreground">
              CAMERA LAB
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden items-center gap-2 text-muted-foreground sm:flex">
            <span className="instrument-mono uppercase">Runtime</span>
            <span className="instrument-mono text-foreground">browser / local</span>
          </div>
          <div className="flex items-center gap-2 border-l border-border pl-4" aria-live="polite">
            <StatusDot state={state} />
            <span className="instrument-mono uppercase text-foreground">
              {state === "running"
                ? "LIVE"
                : state === "error"
                  ? "FAULT"
                  : state === "model-loading"
                    ? "MODEL"
                    : state === "camera-starting"
                      ? "CAMERA"
                      : "STANDBY"}
            </span>
          </div>
        </div>
      </header>

      <section className="flex min-h-0 flex-1 flex-col overflow-y-auto lg:flex-row lg:overflow-hidden">
        <div
          ref={stageRef}
          className="camera-stage h-[46dvh] min-h-[46dvh] flex-none lg:h-auto lg:min-h-0 lg:flex-1"
        >
          <video
            ref={videoRef}
            playsInline
            autoPlay
            muted
            aria-label="Live rear camera preview"
          />
          <div className="camera-grid" aria-hidden="true" />
          <div className="viewfinder" aria-hidden="true" />
          {state === "running" && <div className="scan-line" aria-hidden="true" />}

          {relationshipText && (
            <div className="relationship-hud" role="status" aria-live="polite">
              {relationshipText}
            </div>
          )}

          {positionedDetections.map((detection, index) => (
            <div
              key={`${detection.class}-${index}`}
              className="detection-box"
              style={{
                left: detection.display.left,
                top: detection.display.top,
                width: detection.display.width,
                height: detection.display.height,
              }}
            >
              <span className="detection-label">
                {detection.class} · {Math.round(detection.score * 100)}%
              </span>
            </div>
          ))}

          {!hasStream && (
            <div className="absolute inset-0 z-[5] flex items-center justify-center p-6">
              <div className="max-w-sm text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center border border-foreground/20 bg-stage/70 text-primary">
                  {state === "error" ? (
                    <CircleAlert size={23} strokeWidth={1.4} />
                  ) : state === "idle" ? (
                    <Camera size={23} strokeWidth={1.4} />
                  ) : (
                    <Cpu className="status-pulse" size={23} strokeWidth={1.4} />
                  )}
                </div>
                <p className="instrument-mono mb-2 uppercase text-primary">{statusText}</p>
                <p className="text-sm leading-6 text-foreground/70">
                  {state === "error" && error ? error.detail : statusDescription}
                </p>
              </div>
            </div>
          )}

          <div className="absolute bottom-4 left-4 z-[6] flex items-center gap-2 bg-stage/65 px-2.5 py-1.5 backdrop-blur-sm">
            <span
              className={`h-1.5 w-1.5 rounded-full ${hasStream ? "bg-accent" : "bg-muted-foreground"}`}
            />
            <span className="instrument-mono uppercase text-foreground/70">
              {hasStream ? "Environment camera" : "Preview offline"}
            </span>
          </div>

          {state === "running" && (
            <div className="absolute right-4 top-4 z-[6] flex items-center gap-2 bg-stage/65 px-2.5 py-1.5 backdrop-blur-sm">
              <span className="instrument-mono text-accent">
                {detections.length.toString().padStart(2, "0")}
              </span>
              <span className="instrument-mono uppercase text-foreground/70">objects</span>
            </div>
          )}
        </div>

        <aside className="relative z-10 flex w-full shrink-0 flex-col border-t border-border bg-sidebar/95 lg:w-[22rem] lg:border-l lg:border-t-0 xl:w-[24rem]">
          <div className="flex-1 overflow-y-auto p-4 sm:p-6">
            <div className="mb-7">
              <div className="instrument-mono mb-3 flex items-center gap-2 uppercase text-muted-foreground">
                <span className="h-px w-5 bg-primary" /> Test instrument
              </div>
              <h2 className="max-w-[19rem] text-2xl font-medium leading-tight tracking-[-0.035em] text-foreground">
                Camera + object detection
              </h2>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">
                A direct read on browser camera access and local COCO-SSD inference, limited
                to the two highest-confidence targets.
              </p>
            </div>

            <div className="mb-5 border border-border bg-panel-deep/60">
              <div className="flex items-center justify-between border-b border-border px-3 py-2.5">
                <span className="instrument-mono uppercase text-foreground">Diagnostics</span>
                <Gauge size={14} className="text-muted-foreground" />
              </div>
              <dl className="divide-y divide-border">
                <div className="flex items-center justify-between px-3 py-3">
                  <dt className="instrument-mono text-muted-foreground">Live status</dt>
                  <dd className="instrument-mono uppercase text-foreground">{statusText}</dd>
                </div>
                <div className="flex items-center justify-between px-3 py-3">
                  <dt className="instrument-mono text-muted-foreground">Secure context</dt>
                  <dd className="instrument-mono flex items-center gap-1.5 text-foreground">
                    {secureContext ? (
                      <Check size={13} className="text-accent" />
                    ) : (
                      <CircleAlert size={13} className="text-destructive" />
                    )}
                    {secureContext ? "YES" : "NO"}
                  </dd>
                </div>
                <div className="flex items-center justify-between px-3 py-3">
                  <dt className="instrument-mono text-muted-foreground">Video dimensions</dt>
                  <dd className="instrument-mono text-foreground">{videoDimensions}</dd>
                </div>
                <div className="flex items-center justify-between px-3 py-3">
                  <dt className="instrument-mono text-muted-foreground">COCO-SSD model</dt>
                  <dd
                    className={`instrument-mono ${modelStatus === "READY" ? "text-accent" : "text-foreground"}`}
                  >
                    {modelStatus}
                  </dd>
                </div>
                <div className="flex items-center justify-between px-3 py-3">
                  <dt className="instrument-mono text-muted-foreground">
                    Detected objects (max {MAX_NUM_BOXES})
                  </dt>
                  <dd className="instrument-mono text-accent">{detections.length}</dd>
                </div>
                <div className="flex items-center justify-between px-3 py-3">
                  <dt className="instrument-mono text-muted-foreground">Last scan</dt>
                  <dd className="instrument-mono text-right text-foreground">
                    {formatTime(lastScan)}
                  </dd>
                </div>
              </dl>
            </div>

            <div className="mb-5 flex items-center justify-between border border-border px-3 py-3">
              <div>
                <div className="instrument-mono uppercase text-muted-foreground">
                  Scan cadence
                </div>
                <div className="mt-1 text-sm text-foreground">Throttled local inference</div>
              </div>
              <div className="text-right">
                <div className="font-mono text-lg text-primary">
                  {SCAN_INTERVAL} <span className="text-xs">ms</span>
                </div>
                <div className="instrument-mono uppercase text-muted-foreground">interval</div>
              </div>
            </div>

            <div className="mb-5 border border-border px-3 py-3">
              <div className="instrument-mono uppercase text-muted-foreground">
                Spatial relationship
              </div>
              <p className="mt-1.5 text-sm leading-6 text-foreground">
                {relationshipText || "Awaiting two tracked objects"}
              </p>
            </div>

            {state === "error" && error && (
              <div
                className="mb-5 border border-destructive/45 bg-destructive/10 p-3.5"
                role="alert"
              >
                <div className="flex gap-3">
                  <CircleAlert size={16} className="mt-0.5 shrink-0 text-destructive" />
                  <div>
                    <p className="text-sm font-medium text-foreground">{error.title}</p>
                    <p className="mt-1.5 text-xs leading-5 text-muted-foreground">
                      {error.detail}
                    </p>
                    <p className="instrument-mono mt-3 uppercase text-destructive">
                      {error.action}
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="hidden border-t border-border pt-5 sm:block">
              <div className="mb-2 flex items-center gap-2">
                <LockKeyhole size={13} className="text-muted-foreground" />
                <span className="instrument-mono uppercase text-muted-foreground">
                  Local-only test
                </span>
              </div>
              <p className="text-xs leading-5 text-muted-foreground">
                Frames are read in this browser. No capture, upload, or backend connection is
                used.
              </p>
            </div>
          </div>

          <div className="shrink-0 border-t border-border bg-panel/90 p-4 sm:p-6">
            <button
              type="button"
              onClick={running ? stop : startCamera}
              disabled={state === "model-loading" || state === "camera-starting"}
              className={`flex min-h-12 w-full items-center justify-center gap-2.5 border px-4 text-sm font-semibold tracking-[0.02em] transition-colors disabled:cursor-wait disabled:opacity-65 ${
                running
                  ? "border-border bg-secondary text-foreground hover:bg-secondary/70"
                  : "border-primary bg-primary text-primary-foreground hover:bg-primary/90"
              }`}
            >
              {running ? (
                <Square size={15} fill="currentColor" />
              ) : state === "error" ? (
                <RotateCcw size={16} />
              ) : (
                <Play size={16} fill="currentColor" />
              )}
              {running
                ? "Stop test"
                : state === "error"
                  ? "Retry camera test"
                  : state === "model-loading"
                    ? "Loading model…"
                    : state === "camera-starting"
                      ? "Starting camera…"
                      : "Start camera test"}
            </button>
            <p className="mt-3 flex items-center justify-center gap-2 text-center text-[11px] leading-4 text-muted-foreground">
              <span className="h-1 w-1 rounded-full bg-accent" /> Rear camera preferred ·
              permission requested on start
            </p>
          </div>
        </aside>
      </section>
    </main>
  );
}
